package com.example.radiosun;

import static com.example.radiosun.R.id;

import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;



public class RegistrarUsuario extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrousuario);


    }
}